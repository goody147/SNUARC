function EMx = ElemMass(  d_L,  Xel,   Cab,  C)
global elm_dof
    u=Xel(1:3); 
    theta=Xel(4:6);
    P=Xel(13:15);
    H=Xel(16:18);
    CTCab = C * Cab;
        EMx = zeros(elm_dof+12,elm_dof);
        
        for j=1:3
        e11=[0; 0; 0]; 
        e11(j)=1.0; 
        tmpm = scwMat(e11);
		dCdth = tmpm * C;	
		dCdth = dCdth * Cab;

        e11=[0; 0; 0]; 
        e11(j)=P(j); 
        EMx( 1: 3, j + 3 )= d_L / 2.0*dCdth*P;		%df_{u_i}/dth_dot
        EMx(19:21, j + 3 )=  d_L / 2.0*dCdth*P;		%df_{u_i+1}/dth_dot
        e11=[0; 0; 0]; 
        e11(j)=H(j);
        EMx( 4: 6, j + 3 )= d_L / 2.0*dCdth*H;		%df_{psi_i}/dth_dot
        EMx(22:24, j + 3 )= d_L / 2.0*dCdth*H;		%df_{psi_i+1}/dth_dot
        end
%         Get [T]
    tmpm = rotmat1(theta,0);

    
    EMx(16:18,4:6)= -(Cab'*tmpm);                   %df_{H_i}/dth_dot
    EMx(1:3,13:15)= d_L / 2.0*CTCab;				%df_{u_i}/dP_dot
    EMx(4:6,16:18) = d_L / 2.0*CTCab;				%df_{psi_i}/dH_dot
    EMx(13:15,1:3)= -eye(3);
    EMx(19:21,13:15)= d_L / 2.0*CTCab;				%df_{u_i+1}/dP_dot	
    EMx(22:24,16:18)= d_L / 2.0*CTCab;				%df_{psi_i+1}/dH_dot	
        
end