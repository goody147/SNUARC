function matout = scwMat(inputVec)

matout = zeros(3,3);
	matout(1, 2) = -inputVec(3); matout(2, 1) = inputVec(3);
	matout(1, 3) = inputVec(2);  matout(3, 1) = -inputVec(2);
	matout(2, 3) = -inputVec(1); matout(3, 2) = inputVec(1);

end