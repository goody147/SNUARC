function EJx = ElemJx_static(  d_L,  Xel,  invS,  invM,  strn,  velc,  Cab,  C,  wa)
global tot_dof elm_dof
    e1 = [1;0;0];

    u=Xel(1:3); 
    theta=Xel(4:6);
    F=Xel(7:9);
    M=Xel(10:12);
    P=Xel(13:15);
    H=Xel(16:18);
    gamma=strn(1:3);
    kappa=strn(4:6);
    V=velc(1:3);
    Omega=velc(4:6);

    CTCab = C * Cab;
    EJx = zeros(elm_dof+12,elm_dof);

    
        for j=1 : 3
       
        e11= [0;0;0]; 
        e11(j)=1.0; 
        tmpm1 = scwMat(e11);
        dCdth = tmpm1 * C;
		dCdth = dCdth * Cab;
		tmpm = scwMat(wa);
		tmpm1 = scwMat(e1);
		tmpm2 = scwMat(gamma);
		tmpm3 = scwMat(V);
        
        EJx( 1: 3, j + 3 )=  -dCdth * F + d_L / 2.0*(tmpm*dCdth)*P;						%	df_{u_i}/dth_k
        
        EJx(19:21, j + 3 )= dCdth * F + d_L / 2.0*(tmpm*dCdth)*P;					% df_{u_i+1}/dth_k
        
        EJx( 4: 6, j + 3 )= -dCdth * (M - d_L / 2.0*((tmpm1 + tmpm2)* F - tmpm3 * P)) + d_L / 2.0*(tmpm* dCdth)* H;		% df_{psi_i}/dth_k
        
        EJx(22:24, j + 3 )=  dCdth * (M - d_L / 2.0*((tmpm1 + tmpm2)* F - tmpm3 * P)) + d_L / 2.0*(tmpm* dCdth)* H;		% df_{psi_i+1}/dth_k
        
        EJx( 7: 9, j + 3 )= -d_L / 2.0*dCdth*(e1 + gamma);																% df_{F_i}/dth_k
        
        EJx(25:27, j + 3 )= -d_L / 2.0*dCdth*(e1 + gamma);																% df_{F_i+1}/dth_k
        
        tmpm1 = dCmat1(j, theta);
        EJx(10:12, j + 3 )=  e11 - d_L / 2.0*(tmpm1*Cab)*kappa;													% df_{M_i}/dth_k
        
        EJx(28:30, j + 3 )=-e11 - d_L / 2.0*(tmpm1*Cab)*kappa;													% df_{M_i+1}/dth_k
        
        EJx(13:15, j + 3 )= dCdth * V;																			% df_{P_i}/dth_k
        
        e11=[0;0;0];
        e11(j) = 1.0;
		tmpm1 = scwMat(e11);
		dCdth = tmpm1 * (C');
       
      
        EJx(16:18, j + 3 )= - ((Cab') * dCdth)*wa;													% df_{H_i}/dth_k
        end
   tmpm = scwMat(wa);
    EJx( 1: 3,  7: 9 )= -CTCab;																					% df_{u_i}/dF_k
    EJx( 1: 3, 13:15 )= d_L / 2.0*tmpm*CTCab;																	% df_{u_i}/dP_k
    EJx(19:21,  7: 9 )= CTCab;																					% df_{u_i+1}/dF_k
    EJx(19:21, 13:15 )= d_L / 2.0*tmpm*CTCab;																	% df_{u_i+1}/dP_k
    
    tmpm1 = scwMat(e1);
	tmpm2 = scwMat(gamma);
	Mat = scwMat(F);
    EJx( 4: 6,  7: 9 )= -d_L / 2.0*CTCab*(tmpm1 + tmpm2 - (Mat * invS(1:3,1:3)));								% df_{psi_i}/dF_k
    EJx( 4: 6, 10:12 )=  -CTCab - d_L / 2.0*(CTCab*Mat)* invS(1:3,4:6);											% df_{psi_i}/dM_k
    
	Mat = scwMat(V);
	tmpm4 = scwMat(P);
    EJx( 4: 6, 13:15 )=  d_L / 2.0*CTCab*(Mat - (tmpm4 * invM(1:3,1:3)));										% df_{psi_i}/dP_k
    EJx( 4: 6, 16:18 )= d_L / 2.0*tmpm*CTCab - d_L / 2.0 * (CTCab*tmpm4)* invM(1:3,4:6);						% df_{psi_i}/dH_k
    
    Mat = scwMat(F);
    EJx(22:24,  7: 9 )=  -d_L / 2.0*CTCab*(tmpm1 + tmpm2 - (Mat * invS(1:3,1:3)));								% df_{psi_i+1}/dF_k
    EJx(22:24, 10:12 )= CTCab - d_L / 2.0*(CTCab*Mat)* invS(1:3,4:6);											% df_{psi_i+1}/dM_k
    
   Mat = scwMat(V);
    EJx(22:24, 13:15 )= d_L / 2.0*CTCab*(Mat - (tmpm4 * invM(1:3,1:3)));										% df_{psi_i+1}/dP_k
    EJx(22:24, 16:18 )= d_L / 2.0*(tmpm*CTCab) - d_L / 2.0 * (CTCab*tmpm4)* invM(1:3,4:6);						% df_{psi_i+1}/dH_k	

    
    EJx( 7: 9,  1: 3 )= eye(3);
    EJx( 7: 9,  7: 9 )=  -d_L / 2.0*CTCab*invS(1:3,1:3);														% df_{F_i}/dF_k	
    EJx( 7: 9, 10: 12)= -d_L / 2.0*CTCab*invS(1:3,4:6);															% df_{F_i}/dM_k			
    EJx(25:27,  1: 3 )= -eye(3);
    EJx(25:27,  7: 9 )= -d_L / 2.0*CTCab*invS(1:3,1:3);															% df_{F_i+1}/dF_k
    EJx(25:27, 10: 12)=  -d_L / 2.0*CTCab*invS(1:3,4:6);														% df_{F_i+1}/dM_k		
    
%   Get [invT]
	tmpm2 = rotmat1(theta,1);
    EJx(10:12,  7: 9 )=  -d_L / 2.0*(tmpm2*Cab)*invS(4:6,1:3);													% df_{M_i}/dF_k	
    EJx(10:12, 10:12 )=  -d_L / 2.0*(tmpm2*Cab)*invS(4:6,4:6);													% df_{M_i}/dM_k	
    EJx(28:30,  7: 9 )=  -d_L / 2.0*(tmpm2*Cab)*invS(4:6,1:3);													% df_{M_i+1}/dF_k	
    EJx(28:30, 10:12 )=  -d_L / 2.0*(tmpm2*Cab)*invS(4:6,4:6);													% df_{M_i+1}/dM_k	
    
    EJx(13:15,  1: 3 )= -tmpm;
    EJx(13:15, 13:15 )=  CTCab * invM(1:3,1:3);																	% df_{P_i}/dP_k		
    EJx(13:15, 16:18 )=  CTCab * invM(1:3,4:6);																	% df_{P_i}/dH_k		
    
    EJx(16:18, 13:15 )= invM(4:6,1:3);
    EJx(16:18, 16:18 )= invM(4:6,4:6);    
        
    
end