function ynorm = dynamic_solve(tstep)

global X X_prev X_dotprev X_dot dX Res tot_dof elm_dof grids dL RelV RelV_aero Prerot Forces nload nnode nelem PreOm PreVe PreOm_aero PreVe_aero ;
global Sprop Mprop idprop nstep nprop RelF inode idEvec dt
    Xel = zeros(elm_dof,1);
    Jx = zeros(tot_dof, tot_dof);
    Fx = zeros(tot_dof,1);
    Mx = zeros(tot_dof, tot_dof);
    
    for elem_no= 1: nelem
%         Efx = zeros(elm_dof,elm_dof);
%         Ejx = zeros(elm_dof+12,1);
        
        for i=1: elm_dof
           Xel(i)=X(elm_dof*(elem_no-1)+i+6);
        end
        Cmat = rotmat(Xel(4:6));

        Cab=Prerot(:,1+3*(elem_no-1):3+3*(elem_no-1));

        
        va=RelV(1+3*(elem_no-1):3+3*(elem_no-1));
%         va
%          Eq.(2.10) <X.Shang's thesis>  
        strn= (Sprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1))*Xel(7:12));
        velc= (Mprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1))*Xel(13:18));
        
%          Eq.(2.20) <X.Shang>
        Efx = ElemFx_static(dL(elem_no), Xel, strn, velc, Cab, Cmat, PreOm, va);
%          Appendices A. <X.Shang's thesis>
        Ejx = ElemJx_static(dL(elem_no), Xel, Sprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1)), Mprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1)), strn, velc, Cab, Cmat, PreOm);
    
        Emx = ElemMass(dL(elem_no), Xel, Cab, Cmat);
%          Matrix Assembly
       for j=1:elm_dof+12
            for i= 1: elm_dof
                Jx(18*(elem_no-1)+j,18*(elem_no-1)+6+i)=Ejx(j,i);
                Mx(18*(elem_no-1)+j,18*(elem_no-1)+6+i)=Emx(j,i);
            end
       end
       for j=1:elm_dof+12
            Fx(18*(elem_no-1)+j)=Fx(18*(elem_no-1)+j)+Efx(j);
       end
        
    end
%    external forces
        for i=1: nload
            for j=1: 6
                Fx(18*(inode(i)-1)+j)=Fx(18*(inode(i)-1)+j)-Forces(i,j);
            end
        end
%     Boundary Condition

% 	  Cantilever
	for i=1:3
		Jx(i, i) = 1.0;
		Fx(i) = Fx(i) + X(i);
    end
    
    for i=1: 3
        Jx(3+i,3+i)=1.0;
        Fx(3+i)=Fx(3+i)+X(i+3);
    end
%   free-end (tip)
    for i=1: 6
        Jx(tot_dof-6+i, tot_dof-6+i)=1.0;
        Fx(tot_dof-6+i)=Fx(tot_dof-6+i)+X(tot_dof-6+i);
    end
    
        ynorm=0;


%     dX = mldivide(sparse(Jx), Fx);

     Res = (-Fx - Mx * ((X - X_prev) / dt * 2.0 - X_dotprev));
%          dX = sparse(Jx + Mx/dt*2.0)\Res;
% [L,U] = ilu(sparse(Jx),struct('type','ilutp','droptol',0));
% [dX,fl1,rr1,it1,rv1] = bicgstab(Jx,Fx,tol,maxit,L,U);
tol = 1e-3;
maxit = 300;
% % [L,U] = ilu(sparse(Jx + Mx/dt*2.0),struct('type','ilutp','droptol',1e-13));
% % dX = qmr(sparse(Jx + Mx/dt*2.0),(Res),tol,maxit);
% 
dJ = (Jx + Mx/dt*2.0);
% dJ = decomposition (sparse(Jx + Mx/dt*2.0),'triangular','upper','LUPivotTolerance',[0.1 0.01]);
dX = dJ\speye(size(dJ))*Res;
%  dX = qmr(dJ,(Res),tol,maxit);
% dX = lsqminnorm((Jx + Mx/dt*2.0), Res, 1e-6);

 ynorm = Res'*Res;
    X = X + RelF*(dX);
end