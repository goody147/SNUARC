function Efx = ElemFx_static( d_L,  Xel,  strn,  velc,  Cab,  C,  wa,  va)
global tot_dof elm_dof
    e1 = [1;0;0];

    u=Xel(1:3); 
    theta=Xel(4:6);
    F=Xel(7:9);
    M=Xel(10:12);
    P=Xel(13:15);
    H=Xel(16:18);
    gamma=strn(1:3);
    kappa=strn(4:6);
    V=velc(1:3);
    Omega=velc(4:6);

    CTCab = C * Cab;
    
    Efx = zeros(elm_dof+12,1);
    tmpm = scwMat(wa);
	tmpm1 = scwMat(e1);
	tmpm2 = scwMat(gamma);
	tmpm3 = scwMat(V);

%   F_{u_i}
    Efx(1:3) = -CTCab * F + d_L / 2.0 * (tmpm*CTCab)*P;
%   F_{th_i}
    Efx(4:6) = -CTCab * M + d_L / 2.0 * (-((CTCab * (tmpm1 + tmpm2))*F) + (tmpm * CTCab)*H + (CTCab * tmpm3)*P);
%     F_{u_i+1}
    Efx(19:21) = CTCab * F + d_L / 2.0 * (tmpm*(CTCab*P));
%    F_{th_i+1}
    Efx(22:24) = CTCab * M + d_L / 2.0 * (-((CTCab * (tmpm1 + tmpm2))*F) + (tmpm * CTCab)*H + (CTCab * tmpm3)*P);
    
% 	Get [invT]
	tmpm2 = rotmat1(theta, 1);
%     !!! F_{F_i}
    Efx(7:9) = u - d_L / 2.0 * (CTCab*(e1 + gamma) - Cab * e1);
%     !!! F_{M_i}
    Efx(10:12)= theta - d_L / 2.0 * (tmpm2*Cab)*kappa;
%     !!! F_{F_i}
    Efx(25:27) = -u - d_L / 2.0 * (CTCab*(e1 + gamma) - Cab * e1);
%     !!! F_{M_i}
    Efx(28:30)= -theta - d_L / 2.0 * (tmpm2*Cab)*kappa;
    
%     !!! F_{P_i}
    Efx(13:15)= CTCab * V - va - tmpm * u; 
%     !!! F_{H_i}
    Efx(16:18)= Omega - ((Cab')*(C'))*wa; 
    
end