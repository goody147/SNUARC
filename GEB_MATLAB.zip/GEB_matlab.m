%% GEB MATLAB
clear all; close all; clc;
UNIT_lb2kg = 0.453592;
UNIT_psi2pa = 6894.76;
UNIT_inch2m = 0.0254;
UNIT_DEG2RAD = pi/180;
global X X_prev X_dotprev X_dot dX Res tot_dof elm_dof grids dL RelV RelV_aero Prerot Forces nload nnode nelem PreOm PreVe PreOm_aero PreVe_aero ;
global Sprop Mprop idprop nstep nprop RelF inode idEvec dt
nelem = 10;    % number of elements
nnode = nelem+1; % number of nodes
nprop = 1;
RelF = 1;
L = 10;   %[m]
nstep = 1;
dt = 1e-3;
beam_initial_coord_x = linspace(0, L, nnode);
b = 0.5;  %[m]
h = 0.25; %[m]


E = 210e9;  %[Pa]
nu = 0.3;   %[-]
rho = 7850; %[kg/m^3]

G = E/(2*(1+nu)); %[Pa]

A = b*h; %[m^2]
J = 1/12*b*h*(b^2+h^2);
I_bend =  1/12*b*h^3;
I_lag = 1/12*b^3*h;
EA = E*A;
GJ = G*J;
Kv = G*b*h/2/1.2;
EI_bend = E*I_bend;
EI_lag = E*I_lag;
mu = rho*A; %[kg/m]
mIxx = 1/12*mu*(b^2+h^2);  % kg*m
mIyy = 1/12*mu*(h^2);      % kg*m 
mIzz = 1/12*mu*(b^2);      % kg*m
Sprop = zeros(6,6*nprop);
Mprop = zeros(6,6*nprop);
for k = 1:nprop

    stiff_mat = zeros(6,6);
    stiff_mat(1,1) = EA;
    stiff_mat(2,2) = Kv;
    stiff_mat(3,3) = Kv;
    stiff_mat(4,4) = GJ;
    stiff_mat(5,5) = EI_bend;
    stiff_mat(6,6) = EI_lag;
    mass_mat = zeros(6,6);

    mass_mat(1,1) = mu;
     mass_mat(2,2) =mu;
      mass_mat(3,3) = mu;

       mass_mat(4,4) = mIxx;  % kg*m
       mass_mat(5,5) = mIyy;  % kg*m
       mass_mat(6,6) = mIzz;  % kg*m

Sprop(:,1+6*(k-1):6+6*(k-1)) = inv(stiff_mat);
Mprop(:,1+6*(k-1):6+6*(k-1)) = inv(mass_mat);
end

Rotmat = zeros(3,3*nelem);
init_twist = linspace(0,0,nelem)*UNIT_DEG2RAD;
for i = 1:nelem
    tmp = [1 0 0;
           0 cos(init_twist(i)) -sin(init_twist(i));
           0 sin(init_twist(i)) cos(init_twist(i))];
    Rotmat(1:3,1+3*(i-1):3+3*(i-1)) = tmp;
end
nload = nnode;
Forces = zeros(nload,6);
Forces(end,3) = 1e6;
inode = 1:nnode;
idEvec = 1:nelem;
idprop = ones(nelem,1);

grids = zeros(3,nnode);
dL = zeros(1,nelem);
RelV = zeros(3*nelem,1);
RelV_aero = zeros(3*nelem,1);

Prerot = zeros(3,3*nelem);

% e1 = zeros(3,1);
% e2 = zeros(3,1);
% e3 = zeros(3,1);
b = [0;1;0];


PreOm = [0 ; 0;  0];  % rotvel of beam
PreVe = [0 ; 0 ; 0];  % linvel of beam
PreOm_aero = [0; 0;0];   % aero velocity
PreVe_aero = [0 ;0 ;0];

grids(1,:) = beam_initial_coord_x;


tot_dof = 18*nelem+12;
elm_dof = 18;
X = zeros(tot_dof,1);
X_prev = zeros(tot_dof,1);
X_dotprev = zeros(tot_dof,1);
X_dot = zeros(tot_dof,1);
dX = zeros(tot_dof,1);
Res = zeros(tot_dof,1);
nlift = 20; 
ndrag = 20;
nmoment = 20;
	v_a3_prev = zeros(nload,1);
	v_a3_dot_prev = zeros(nload,1);
	w1_prev = zeros(nload,1);
	w1_dot_prev = zeros(nload,1);
	tip_f = zeros(nload,1);
	dL_def = zeros(nload,1);
    a_lift = zeros(nlift,3);
    a_drag = zeros(ndrag,3);
	a_moment =zeros(nmoment,3);
    
for i = 1:nelem
   dx = grids(1,i+1) - grids(1,i);
   dy = grids(2,i+1) - grids(2,i); 
   dz = grids(3,i+1) - grids(3,i);
   dL(i) = sqrt(dx^2 + dy^2 + dz^2);
%    velocity components including rotation effect
        e1 = [0;0;0;];
			e1(1) = grids(1, i+1) + dx / 2.0;
			e1(2) = grids(2, i+1) + dy / 2.0;
			e1(3) = grids(3, i+1) + dz / 2.0;
		tmp = zeros(3,3);
		tmp(1, 2) = -PreOm(3); tmp(2, 1) = PreOm(3);
		tmp(1, 3) =  PreOm(2); tmp(3, 1) = -PreOm(2);
		tmp(2, 3) = -PreOm(1); tmp(3, 2) = PreOm(1);

		RelV(1+3*(i-1):3+3*(i-1)) = PreVe + tmp * e1;

		tmp = zeros(3,3);
		tmp(1, 2) = -PreOm_aero(3); tmp(2, 1) = PreOm_aero(3); 
		tmp(1, 3) =  PreOm_aero(2); tmp(3, 1) = -PreOm_aero(2);
		tmp(2, 3) = -PreOm_aero(1); tmp(3, 2) = PreOm_aero(1);
		RelV_aero(1+3*(i-1):3+3*(i-1)) = PreVe_aero + tmp * e1;
% 		 rotational operator for beam configuration
        e1 = [dx/dL(i); dy/dL(i);  dz/dL(i);];
        e3 = [e1(2)*b(3) - e1(3)*b(2); -e1(1)*b(3) + e1(3)*b(1);  e1(1)*b(2) - e1(2)*b(1);];
        e2 = [e3(2)*e1(3) - e3(3)*e1(2); e3(3)*e1(1) - e3(1)*e1(3); e3(1)*e1(2) - e3(2)*e1(1);];

		tmp = [e1 e2 e3];
		tmp1 = Rotmat(1:3,1+3*(idEvec(i)-1):3+3*(idEvec(i)-1));
		
		Prerot(:,1+3*(i-1):3+3*(i-1)) = (tmp* tmp1);  
   
end

%% Static_solve
clc;
rotval = PreOm;
itermax = 1000000;
global Jx Fx
    for iload=0:2
    
        for i=1:nelem
            dx = grids(1,i+1) - grids(1,i);
            dy = grids(2,i+1) - grids(2,i); 
            dz = grids(3,i+1) - grids(3,i);
            e1(1) = grids(1, i+1) + dx / 2.0;
			e1(2) = grids(2, i+1) + dy / 2.0;
			e1(3) = grids(3, i+1) + dz / 2.0;
            
            PreOm=rotval/(nstep)*(iload);
            tmp=zeros(3,3);
            tmp(1,2)=-PreOm(3); tmp(2,1)= PreOm(3);
            tmp(1,3)= PreOm(2); tmp(3,1)=-PreOm(2);
            tmp(2,3)=-PreOm(1); tmp(3,2)= PreOm(1);
            RelV(1+3*(i-1):3+3*(i-1))= PreVe+tmp*e1;

        end
        for iter = 1: itermax
            ynorm = static_solve(iload);
            X = X - RelF*(dX);

            disp(sqrt(ynorm))

            if (ynorm < 1e-8) break;
            end
            
        end
% %        postp (iload)
%         if (idmod == 1) 
%             Eigen (iload)
%         end
    end  

%% Dynamic_solve
clc;
rotval = PreOm;
itermax = 1000000;
    for tstep=0:nstep
    
        for iter = 1: itermax
            X_dot = (X - X_prev) / (0.5 * dt) - X_dotprev;
            ynorm = dynamic_solve(tstep);
            disp(ynorm);
            if (ynorm < 1e-8) break;
            end
        end
        X_prev = X;
		X_dotprev = X_dot;
         disp(['** TIME STEP' tstep '  CURRENT TIME'  tstep*dt])
% %        postp (tstep)
        Forces = zeros(nload,6);
    end  