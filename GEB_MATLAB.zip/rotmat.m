function matout = rotmat(inputVec)
	
	 th0 = inputVec(1);
	 th1 = inputVec(2);
	 th2 = inputVec(3);
	 thc = sqrt(th0*th0 + th1 * th1 + th2 * th2);
	
	t_th = zeros(3,3);
	t_th(1, 2) = -th2; t_th(2, 1) = th2;
	t_th(1, 3) = th1; t_th(3, 1) = -th1;
	t_th(2, 3) = -th0; t_th(3, 2) = th0;

	

	if (thc == 0)
		matout = eye;
        
    else
        
		matout = eye + sin(thc) / thc * t_th + (2.0 *sin(thc/2.0)*sin(thc/2.0)) / (thc*thc)*(t_th*t_th);
    end
    

end