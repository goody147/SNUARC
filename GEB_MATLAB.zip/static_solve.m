function [ynorm,x] = static_solve(iload)

global X X_prev X_dotprev X_dot dX Jx Fx Res tot_dof elm_dof grids dL RelV RelV_aero Prerot Forces nload nnode nelem PreOm PreVe PreOm_aero PreVe_aero ;
global Sprop Mprop idprop nstep nprop RelF inode idEvec
    Xel = zeros(elm_dof,1);
    Jx = zeros(tot_dof, tot_dof);
    Fx = zeros(tot_dof,1);
    for elem_no= 1: nelem
        Efx = zeros(elm_dof,elm_dof);
        Ejx = zeros(elm_dof+12,1);
        for i=1: elm_dof
           Xel(i)=X(elm_dof*(elem_no-1)+i+6);
        end
        Cmat = rotmat(Xel(4:6));

        Cab=Prerot(:,1+3*(elem_no-1):3+3*(elem_no-1));

        
        va=RelV(1+3*(elem_no-1):3+3*(elem_no-1));
%         va
%          Eq.(2.10) <X.Shang's thesis>  
        strn= (Sprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1))*Xel(7:12));
        velc= (Mprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1))*Xel(13:18));
        
%          Eq.(2.20) <X.Shang>
        Efx = ElemFx_static(dL(elem_no), Xel, strn, velc, Cab, Cmat, PreOm, va);
%          Appendices A. <X.Shang's thesis>
        Ejx = ElemJx_static(dL(elem_no), Xel, Sprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1)), Mprop(:,1+6*(idprop(elem_no)-1):6+6*(idprop(elem_no)-1)), strn, velc, Cab, Cmat, PreOm);

            
%          Matrix Assembly
       for j=1:elm_dof+12
            for i= 1: elm_dof
                Jx(18*(elem_no-1)+j,18*(elem_no-1)+6+i)=Ejx(j,i);
            end
       end
       for j=1:elm_dof+12
            Fx(18*(elem_no-1)+j)=Fx(18*(elem_no-1)+j)+Efx(j);
       end
        
    end

        for i=1: nload
            for j=1: 6
                Fx(18*(inode(i)-1)+j)=Fx(18*(inode(i)-1)+j)-Forces(i,j)/(nstep)*(iload);
            end
        end
%     Boundary Condition

% 	  Cantilever
	for i=1:3
		Jx(i, i) = 1.0;
		Fx(i) = Fx(i) + X(i);
    end
    
    for i=1: 3
        Jx(3+i,3+i)=1.0;
        Fx(3+i)=Fx(3+i)+X(i+3);
    end
%   free-end (tip)
    for i=1: 6
        Jx(tot_dof-6+i, tot_dof-6+i)=1.0;
        Fx(tot_dof-6+i)=Fx(tot_dof-6+i)+X(tot_dof-6+i);
    end
    
        ynorm=0;
    for i=1:tot_dof
        ynorm=ynorm+Fx(i)*Fx(i);
    end

CRS = struct;
[val,r,c]=sparse2csr((Jx),1);
CRS.values=val;
CRS.column_index=c;
CRS.row_index = find(r==c);
[iter_counter, iter_error, x]=CRS_GS(CRS, Fx, dX,  1e-3);
%     dX = x;
    iter_counter
    iter_error
     
end